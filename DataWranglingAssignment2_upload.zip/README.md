# DataWranglingAssignment2

Reproduction of the main experiment of **FAHES: A Robust Disguised Missing Values Detector** (Qahtan, Elmagarmid, Fernandez, Ouzzani, Tang; KDD 2018). This repository belongs to Assignment 2 of the course Data Wrangling (Utrecht University). The report is submitted together with this code.

## What is in this repository

- `pFAHES_patched/`: the Python port of FAHES (https://github.com/hqahtan/pFAHES) with five small fixes. The changes are listed in the appendix of the report and summarized in `CODE_REVIEW.md`. The `Data` folder is not included.
- `scripts/`: the scripts used for the experiments.
  - `driver.py` runs one module (syntactic, numerical or random) on one table, with a time limit.
  - `score.py` computes precision and recall per data source against the ground truth.
  - `retry.py` removes entries from a run, so that they can run again.
  - `run_module.py` runs one module on one table (it is called by `driver.py`).
  - `datasets*.txt` list the tables for the full run, for the Road Safety tables, and for all other tables.
- `results/`: the output of the runs. `results/orig` belongs to the original code and `results/patched` to the patched code. Each module and table has a JSON file with the detected values and the running time. `status.json` records which runs finished, timed out or failed.
- `CODE_REVIEW.md`: bugs and deviations from the paper that were found while reading the code.

## How to reproduce

1. Install Python 3.13 and pandas: `pip install pandas`.
2. Download the original repository https://github.com/hqahtan/pFAHES, unzip it and rename the folder to `pFAHES_original`. Put it in this repository's folder, next to `scripts/` and `pFAHES_patched/`. Its `Data` folder contains the tables and the ground truth.
3. Open PowerShell in the `scripts` folder and run:

```
$env:FAHES_GT_ROOT = "..\pFAHES_original\Data\DataWithGroundTruth\"
python driver.py ..\pFAHES_original orig syn=600,od=300,rand=600
python driver.py ..\pFAHES_patched patched syn=600,od=300,rand=600
python score.py orig
python score.py patched
```

On macOS or Linux, use `export FAHES_GT_ROOT=../pFAHES_original/Data/DataWithGroundTruth/` and forward slashes.

Notes:
- The number after each module (`syn=`, `od=`, `rand=`) is its time limit in seconds for one table. A table that is too slow is recorded as a timeout.
- Runs that already have an entry in `status.json` are skipped. To run a timed-out module again, first remove its entry, for example `python retry.py orig "Mass1|od"`, and then run `driver.py` again.
- For the Road Safety tables, first set `$env:DATASETS = "datasets_road.txt"`. For the other tables use `datasets_nonroad.txt`.
- The results in the report were produced with Python 3.13.9 and pandas 3.1.0 on Windows.

## Known problems

- The numerical module (`OD`) crashes with a division by zero on the AERS table.
- The numerical and random modules exceed the time limits on the largest tables (for example Mass1 and Accidents_2015). `score.py` counts such modules as having found nothing, and `status.json` records the timeout.
- See `CODE_REVIEW.md` for the complete list.

## Credits

FAHES was developed by Qahtan, Elmagarmid, Fernandez, Ouzzani and Tang. The Python port is linked above. The changes in `pFAHES_patched/` and the scripts in `scripts/` were written for this assignment.
