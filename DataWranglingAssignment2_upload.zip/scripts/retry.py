"""Remove entries from a run's status file so that they run again.
usage (from the scripts folder): python retry.py <tag> "<table>|<module>" ...
example: python retry.py orig "Mass1|od" "Accidents_2015|rand"
After this, start driver.py again with the same tag."""
import json, sys
tag = sys.argv[1]
keys = sys.argv[2:]
p = f'out/{tag}/status.json'
s = json.load(open(p))
for k in keys:
    print(k, '->', s.pop(k, 'not found'))
json.dump(s, open(p, 'w'))
