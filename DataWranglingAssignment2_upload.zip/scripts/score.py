import json, sys, os, collections
TAG = sys.argv[1] if len(sys.argv) > 1 else 'orig'
GTDIR = os.environ.get('FAHES_GT_ROOT', 'pFAHES-master/Data/DataWithGroundTruth/') + 'GT/'
SOURCES = {
 'UCI ML-Repo.': ['adult','elnino','tao','pima'],
 'data.gov':     ['10151-1','12252-1','16834-1','323-1','3397-1'],
 'data.gov.uk':  ['Accidents_2015','Casualties_2015','Vehicles_2015'],
 'mass.gov':     ['Mass1','Mass2','Mass3','Mass4','Mass5','Mass6'],
 'FDA (extra)':  ['AERS'],
}
GT_NAME = {'pima':'pima-indians-diabetes'}      # table name used in the GT file
def norm(v):
    v = str(v).strip().casefold()
    try: return repr(float(v.replace(',','')))
    except: return v
gt = collections.defaultdict(set)
for f in os.listdir(GTDIR):
    for line in open(GTDIR+f, encoding='utf-8', errors='replace').read().splitlines():
        if '::' not in line: continue
        t, a, v = line.split('::', 2)
        gt[t].add((a.strip(), norm(v)))
def load(name, m):
    p = f'out/{TAG}/{name}__{m}.json'
    return json.load(open(p)) if os.path.exists(p) else None
DROP_EMPTY = os.environ.get('DROP_EMPTY') == '1'
FAILED = []
def reported(name, mods):
    s = set(); tm = 0; got = 0
    for m in mods:
        r = load(name, m)
        if r is None:
            if len(mods) > 1: FAILED.append(f'{name}:{m}')
            continue
        got += 1
        tm += r['time']
        s |= {(a.strip(), norm(v)) for a, v, f, t in r['dmvs'] if not (DROP_EMPTY and str(v).strip() == '')}
    return s, tm, got > 0
CONFIGS = [('SYN',['syn']),('OD',['od']),('Rand',['rand']),('All (union)',['syn','od','rand'])]
print(f"{'source':14s}{'tbl':>4s}{'#GT':>5s} | " + " | ".join(f"{c[0]:^21s}" for c in CONFIGS))
rows = {}
for src, names in SOURCES.items():
    out = []
    used = []
    for cname, mods in CONFIGS:
        tp = rep = tot = 0; used = []
        for n in names:
            s, tm, ok = reported(n, mods)
            if not ok: continue
            used.append(n)
            g = gt[GT_NAME.get(n, n)]
            tp += len(s & g); rep += len(s); tot += len(g)
        P = tp/rep if rep else float('nan'); R = tp/tot if tot else float('nan')
        out.append((P, R, tp, rep, tot))
    rows[src] = (used, out)
    print(f"{src:14s}{len(used):>2d}/{len(names):<1d}{out[0][4]:>5d} | " + " | ".join(f"P={o[0]:.3f} R={o[1]:.3f}  " for o in out))
json.dump({k: v[1] for k, v in rows.items()}, open(f'out/{TAG}/scores.json', 'w'))
print('modules that failed/timed out (counted as: found nothing):', sorted(set(FAILED)))
print("\nruntime (s), all three modules summed:")
for src, names in SOURCES.items():
    for n in names:
        s, tm, ok = reported(n, ['syn','od','rand'])
        parts = [ (load(n,m) or {}).get('time') for m in ['syn','od','rand']]
        print(f"  {n:16s}", ' '.join(f"{m}={p:.2f}" if p is not None else f"{m}=NA" for m,p in zip(['syn','od','rand'],parts)), f"total={tm:.2f}" + ("" if ok else " (incomplete)"))
