import subprocess, sys, os, json, time
REPO = sys.argv[1]; TAG = sys.argv[2]; _a = sys.argv[3]
TO = json.loads(_a) if _a.lstrip().startswith('{') else {k: int(v) for k, v in (p.split('=') for p in _a.split(','))}   # e.g. syn=600,od=300,rand=600   # per-module timeouts
ROOT = os.environ.get('FAHES_GT_ROOT', 'pFAHES-master/Data/DataWithGroundTruth/')
datasets = [l.split() for l in open(os.environ.get('DATASETS','datasets.txt')) if l.strip()]
os.makedirs(f'out/{TAG}', exist_ok=True)
status = {}
if os.path.exists(f'out/{TAG}/status.json'): status = json.load(open(f'out/{TAG}/status.json'))
for name, path in datasets:
    for m in ['syn', 'od', 'rand']:
        key = f'{name}|{m}'
        if key in status and status[key] != 'timeout_retry': continue
        out = f'out/{TAG}/{name}__{m}.json'
        t0 = time.time()
        try:
            r = subprocess.run([sys.executable, 'run_module.py', REPO, ROOT + path, m, out],
                               capture_output=True, text=True, timeout=TO[m])
            status[key] = 'ok' if r.returncode == 0 else ('error: ' + (r.stderr.strip().splitlines()[-1][:200] if r.stderr.strip() else f'process killed, return code {r.returncode} (probably out of memory)'))
        except subprocess.TimeoutExpired:
            status[key] = 'timeout'
        print(key, status[key], round(time.time() - t0, 1), flush=True)
        json.dump(status, open(f'out/{TAG}/status.json', 'w'))
