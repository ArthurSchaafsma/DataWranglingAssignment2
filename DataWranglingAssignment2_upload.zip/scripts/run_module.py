"""Run ONE pFAHES module on ONE csv and dump the detected DMVs + runtime as JSON.
usage: python run_module.py <repo_dir> <csv> <syn|od|rand> <out.json>"""
import sys, json, time
repo, csv_path, module, out = sys.argv[1:5]
sys.path.insert(0, repo)
import common, patterns, DV_Detector, RandDMVD, OD   # (fahes is imported indirectly)
T = common.read_table(csv_path)
t0 = time.time()
dmvs = []
if module == 'syn':
    dmvs, _ = patterns.find_all_patterns(T, dmvs)
    dmvs = DV_Detector.check_non_conforming_patterns(T, dmvs)
elif module == 'rand':
    dmvs = RandDMVD.find_disguised_values(T, dmvs)
elif module == 'od':
    dmvs = OD.detect_outliers(T, dmvs)
el = time.time() - t0
json.dump({"time": el, "rows": len(T), "cols": len(T.columns),
           "dmvs": [[d.attr_name, d.value, d.frequency, d.tool_name] for d in dmvs]}, open(out, 'w'))
