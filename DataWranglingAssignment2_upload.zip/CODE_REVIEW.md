# pFAHES code review (repository as downloaded, `pFAHES-master`)

Environment used for the review: Python 3.12.3, pandas 3.0.2 (Linux sandbox). The Windows runs used Python 3.13.9 and pandas 3.1.0 and gave the same scores. Verified = reproduced by running the code.

## Bugs (verified)
| # | Where | Problem | Effect |
|---|-------|---------|--------|
| 1 | `common.read_table` | `read_csv` without `keep_default_na=False`: "NA", "N/A", "null", ... become NaN and vanish from `value_counts()`. The commented-out line 53 of `fahes.py` still has `keep_default_na=False`. | DMVs like `N/A` are never seen (0/8 found in 3397-1). Largest effect on the results. |
| 2 | `OD.isNumber`, `DV_Detector.isNumber` | `s[0]` on an empty string -> `IndexError`. Only hidden because of bug 1. | Crash once bug 1 is fixed. |
| 3 | `fahes.py` | `ptrns` only defined for tool codes 1 and 4. | Tool codes 2 and 3 crash with `UnboundLocalError` after the CSV is written. |
| 4 | `patterns.determine_dominating_patterns` | `1 - 3.0/total_dist_vals` with 0 distinct values. | `ZeroDivisionError` on an empty column. |
| 5 | `OD.detect_outliers` | `numeric_data[val] = v2` overwrites when "5" and "5.0" parse to the same float. | Tuples are dropped (10 of 23 in a test). |
| 6 | `OD` on AERS | `ZeroDivisionError`. | Cause not found (possibly `f_max == 0`; not verified). |
| 7 | README / data | README says `main.py` and clones `qahtanaa/pFAHES`. `Data/Mass1-3.csv` equal `Mass3-5.csv` of `DataWithGroundTruth/Mass` (MD5). | Wrong file / wrong ground truth if used by name. |
| 8 | `RandDMVD.Table_Index_RandDMVD` | Stores a row copy for every cell. | Out of memory (about 3.9 GB) on the Road Safety tables. |

## Suspicious (not shown to matter in my runs)
* `RandDMVD.record_correlation`: `compute_num_cooccur(Vec, i, ...)` uses the stale loop variable `i` (probably `idx`). No change on Pima.
* `patterns.apply_L5_tricks`, line 160: condition can never be true (dead code).
* `Special_Alphabet` uses `true` / `false` (never called). Mixed tabs and spaces.
* `fahes` <-> module circular imports (works, fragile). `bool` shadows the builtin.
* Output files are not closed; "nothing" is printed and an empty file is left behind; `tabn[0:len(tabn)-4]` assumes a 4-character extension; `check_d_quotation` only handles commas.
* RandomDMVD reports lower-cased values (compare case-insensitively).

## Deviations from the paper (by reading the code)
* Numeric module: Epanechnikov instead of Gaussian kernel, h0 = 2.345 s n^-1/5 instead of 1.06 s n^-1/5, 4 instead of 5 bandwidths, keeps the maximum density (= minimum score) instead of the maximum score, flags only density exactly 0 instead of tau = 0.99 mean-density; skips columns with < 10 numeric or >= 3 non-numeric distinct values; only values occurring more than once.
* SynPat: fixed five-level cascade instead of the greedy rule search of Algorithm 1; the 1 % rule is replaced by a dominance cut-off (0.7-0.97) and a "fewer than 4 values" rule; extra type checks.
* Repeated patterns: only one repeated character, length >= 5; Eq. (1) not implemented.
* RandomDMVD: no subspace search (all columns with >= 3 distinct values), ratio instead of log mutual information, factor N/|sub-table|, one best value per attribute, extra filters (frequency > 5, ratios > 1 %).

## Verdict
The code runs and gives plausible output, but it is not correct as shipped: it hides null-like strings, crashes in several cases and differs from the paper's description. With the five minimal fixes listed in the report appendix the union module reaches the paper's recall on data.gov and data.gov.uk and its precision on UCI.
